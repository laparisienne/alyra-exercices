const express = require('express');
const router = express.Router();
const multer = require('multer');

var flashErrors = {
    '1': 'Please enter a valid value',
    '2': 'Please select a file',
    '3': 'Please select a conversion type',
    '4': 'Please enter a valid value to process',
    '5': 'Please enter a valid file to process',
    '6': 'Url is invalid',
    '7': 'Input is not valid hexadecimal',
    '8': 'Input is not valid json'
};

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname)
    }
});

var upload = multer({storage: storage});

/* GET home page. */
router.get('/', function (req, res) {
    res.render('index', {title: 'Outil de conversion Bitcoin'});
});

router.post('/convert', function (req, res) {
    if (req.body.value === '' || req.body.select === '') {
        if (req.body.value === '')
            req.flash('error', flashErrors[1]);
        else
            req.flash('error', flashErrors[3]);
        res.redirect('/');
    } else {
        let Expr = require('../models/expr');
        if ((ret = Expr.parse(req.body.value.replace(/\s+/g, ''), req.body.select)) > 0) {
            req.flash('error', flashErrors[ret]);
            res.redirect('/');
        } else {
            req.flash('success', req.body.value + " converted to " + Expr.result);
            res.redirect('/');
        }
    }
});

router.post('/decode', upload.single('file'), function (req, res, next) {
    let Block = require('../models/block');
    Block.dataType = req.body.dataType;
    Block.format = (req.body.isHex === 'on') ? 'hex' : 'json';
    let ret;
    if (req.body.inputType === 'byInput') {
        let input = req.body.input.trim();
        if (input === '') {
            req.flash('error', flashErrors[1]);
            res.redirect('/');
        }
        if ((ret = Block.getDataFromInput(input)) > 0) {
            req.flash('error', flashErrors[ret]);
            res.redirect('/');
        }
    } else {
        if (req.file === undefined) {
            req.flash('error', flashErrors[2]);
            res.redirect('/');
        }
        if ((ret = Block.getDataFromFile(req.file.path)) > 0) {
            req.flash('error', flashError[ret]);
            res.redirect('/');
        }
    }

    if ((ret = Block.checkIntegrity()) > 0) {
        req.flash('error', flashErrors[ret]);
        res.redirect('/');
    }
    if (req.body.inputType === 'byFile')
        Block.deleteFile(req.file.path);
    if (req.body.inputType === 'byInput')
        req.flash('success', "Input processed. See below for results");
    else
        req.flash('success', req.file.originalname.replace(/\s+/g, '') + " processed");
    req.display(Block.dataType, Block.result);
    res.redirect('/');
});

module.exports = router;
