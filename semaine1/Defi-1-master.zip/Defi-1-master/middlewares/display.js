module.exports = function (req, res, next) {

    if (req.session !== undefined) {
        res.locals.display = req.session.display;
        req.session.display = undefined;
    }
    req.display = function (dataType, result) {
        if (req.session.display === undefined)
            req.session.display = {};
        req.session.display[dataType] = result;
    };
    next()
};