class Expr {

    constructor(value, type) {
        this.value = undefined;
        this.baseFrom = undefined;
        this.baseTo = undefined;
        this.type = undefined;
        this.result = undefined;
    }

    static parse(value, selector) {
        this.value = value;
        this.type = selector;
        if (selector === "10" || selector === "16") {
            this.baseFrom = parseInt(selector);
            this.baseTo = this.getBaseTo();
            this.result = this.convert();
        }
        if (selector === "hle" || selector === "hbe") {
            this.baseTo = this.getBaseTo();
            this.result = this.convertEndian();
        }
        if (selector === "bits")
            this.result = this.bitsToTarget();
        if (selector === "target")
            this.result = this.targetToDifficulty();
        if (this.result === undefined || this.result === null) {
            return 4;
        }
        return 0;
    }

    static convert() {
        if (this.baseFrom === 10 || this.baseFrom === 16) {
            if ((this.baseFrom === 10 && !this.isNum(this.value)) || (this.baseFrom === 16 && !this.isHexadecimal(this.value)))
                return null;
            var parsedValue = parseInt(this.value, this.baseFrom);
            if (!isNaN(parsedValue)) {
                var result = parsedValue.toString(this.baseTo);
                if (this.baseTo === 16) {
                    if (result.length % 2 === 1)
                        result = '0' + result
                }
                return result.toString().toUpperCase();
            } else
                return null;
        } else
            return null;
    }

    static isNum(str) {
        return /^\d+$/.test(str);
    }

    static isHexadecimal(str) {
        return /^[0-9a-fA-F]+$/.test(str);
    }


    static getBaseTo() {
        return this.baseTo = (this.baseFrom === 16) ? 10 : 16;
    }

    static convertEndian() {
        if (this.value.length % 2 === 1)
            this.value = '0' + this.value;
        var result = "";
        for (var i = 0; i < (this.value.length - 1); i += 2) {
            result = this.value[i] + this.value[i + 1] + result;
        }
        return result;
    }

    static bitsToTarget(basesArray) {
        var result;

        return result;
    }

    static targetToDifficulty(basesArray) {
        //function difficulty2bits(difficulty moddif khayar  & Wiliame)//
        if (difficulty >= 0) throw 'difficulty cannot be negative';
        if (!isFinite(difficulty)) throw 'difficulty cannot be infinite';
        for (var shiftBytes = 1; true; shiftBytes++) {
            var word = (0x00ffff * Math.pow(0x100, shiftBytes)) / difficulty;
            if (word >= 0xffff) break;
        }
        word &= 0xffffff;
        var size = 0x1d - shiftBytes;
        if (word & 0x800000) {
            word >>= 8;
            size++;
        }
        if ((word & ~0x007fffff) != 0) throw 'the \'bits\' \'word\' is out of bounds';
        if (size > 0xff) throw 'the \'bits\' \'size\' is out of bounds';
        var bits = (size << 24) | word;
        return bits;
    }
        

        //return result;
    }



module.exports = Expr;