const fs = require('fs');
const axios = require('axios');
const prettyPrintJson = require('pretty-print-json');

class Block {

    constructor(data) {
        this.data = data;
        this.dataType = undefined;
        this.format = undefined;
        this.result = undefined;
    }

    static display(callback) {

    }

    static displayBlock(callback) {

    }

    static displayTransaction(callback) {

    }

    static getDataFromInput(data) {
        if (this.isUrl(data)) {
            this.httpClient(data);
            if (this.data === undefined || this.data === '') {
                return 6;
            }
        } else
            this.data = data;
        return 0;
    }

    static getDataFromFile(filePath) {
        var data = fs.readFileSync(filePath, 'utf8');
        if (!data)
            return 5;
        this.data = data.replace(/\s+/g, '');
        return 0;
    }

    static checkIntegrity() {
        if (this.format === 'hex') {    // if input is hex
            if (!this.isHexadecimal(this.data))
                return 7;
            this.result = this.data;
        } else {              // if input is json
            let json;
            if ((json = this.tryParseJSON(this.data)) === null)
                return 8;
            this.result = prettyPrintJson.toHtml(json);
        }
        return 0;
    }

    static isHexadecimal(str) {
        return /^[0-9a-fA-F]+$/.test(str);
    }

    static tryParseJSON(jsonString) {
        try {
            let json = JSON.parse(jsonString);
            if (json && typeof json === "object") {
                return json;
            }
        } catch (error) {
        }
        return null;
    };

    static deleteFile(filePath) {
        fs.unlink(filePath, function (error) {
            if (error) {
                throw error;
            }
            console.log(filePath + ' deleted');
        });
    }

    static isUrl(data) {
        const pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
            '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
            '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
            '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
            '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
            '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
        return !!pattern.test(data);
    }

    static httpClient(url) {
        axios.get(url)
            .catch(function (error) {
                throw error;
            })
            .then((response) => {
                this.data = response['data'];
                console.log(this.data)
            });
    };
}

module.exports = Block;